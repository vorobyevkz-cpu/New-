var APP_DATA = {
  "scenes": [
    {
      "id": "0-img_0113",
      "name": "IMG_0113",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 190,
      "initialViewParameters": {
        "yaw": -1.4839379965316049,
        "pitch": 0.024332972994105972,
        "fov": 1.336535022798044
      },
      "linkHotspots": [
        {
          "yaw": 1.6991911499597343,
          "pitch": 0.147066945634716,
          "rotation": 0,
          "target": "1-img_0113"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-img_0113",
      "name": "IMG_0113",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 190,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
